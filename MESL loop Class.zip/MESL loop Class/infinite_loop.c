#include<stdio.h>
int main()
{
    //int i = 1;
    while(1){
        printf("hello\n");
        //i++;
    }
    return 0;
}