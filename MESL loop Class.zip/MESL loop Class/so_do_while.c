


#include<stdio.h>
int main()
{
    int i=0;
    do{
        printf("%d\n",i);
        i+=2;
    }while(i<=10);
    return 0;
}